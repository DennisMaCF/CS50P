import emoji

def main():
    # 提示使用者輸入待轉換的字串
    prompt = input("Input: ")

    # 轉換表情符號代碼
    output = emojize_text(prompt)

    # 輸出轉換後的結果
    print(f"Output: {output}")


def emojize_text(prompt):
    """
    將使用者輸入的字串中的 emoji 代碼轉換為相應的表情符號。
    :param prompt: 使用者輸入的字串
    :return: 轉換後的表情符號字串
    """
    # 使用 emoji 模組將代碼轉換為表情符號
    try:
        emojized_text = emoji.emojize(prompt, language='alias')  # 支援別名轉換
        return emojized_text
    except Exception as e:
        print(f"轉換過程中出現錯誤: {e}")
        return prompt  # 如果轉換失敗，返回原始字串


if __name__ == "__main__":
    main()
