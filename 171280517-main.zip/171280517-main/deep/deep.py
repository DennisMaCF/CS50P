def main():
    ans()

def ans():
    ans = str(input("What is the Answer to the Great Question of Life, the Universe, and Everything? ")).lower().strip()
    if ans in ["42", "forty two", "forty-two"," 42"]:
        print("Yes", end="")
    else:
        print("No", end="")

main()
