
word = str(input("輸入任何為大寫的英文")).lower()
print(word)
