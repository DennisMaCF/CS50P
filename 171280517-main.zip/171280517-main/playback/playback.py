words = str(input("請輸入一段英文字。 ")).replace(" ", "...")
print(words)
